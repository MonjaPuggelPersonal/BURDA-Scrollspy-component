$(document).ready(function(){

    /**
     * @description calls the scrollspy function on the main class
     */
    $(".main").scrollspy({
        sectionContainer: "section", // please type in the selector here, which will be used for the scrolling functionality
        animationTime: 900 //please define here how long the animations should take
    });

});
