!function($){

    var defaults = {
        sectionContainer: "section",
        animationTime: 1000
    };

    /**
     * @description applies scroll spying to the navigation and the click events on the list items
     * @param options
     * @returns {*}
     */
    $.fn.scrollspy = function(options){

        return this.each(function () {

            var settings = $.extend({}, defaults, options),
                el = $(this),
                sections = $(settings.sectionContainer),
                sectionsLength = sections.length,
                topPos = 0,
                lastAnimation = 0,
                quietPeriod = 0;

            /**
             * @description animates the scrolling movement
             * @param settings
             * @param pos
             */
            $.fn.scrollPage = function(settings, pos) {

                $(this).css({
                    "-webkit-transform": "translate3d(0, " + pos + "%, 0)",
                    "-webkit-transition": "all " + settings.animationTime + "ms " + "ease",
                    "-moz-transform": "translate3d(0, " + pos + "%, 0)",
                    "-moz-transition": "all " + settings.animationTime + "ms " + "ease",
                    "-ms-transform": "translate3d(0, " + pos + "%, 0)",
                    "-ms-transition": "all " + settings.animationTime + "ms " + "ease",
                    "transform": "translate3d(0, " + pos + "%, 0)",
                    "transition": "all " + settings.animationTime + "ms " + "ease"
                });
            };

            /**
             * @description changes the classes on the list items while scrolling down
             */
            $.fn.moveDown = function() {
                var el = $(this);
                index = $(settings.sectionContainer +".active").data("index");

                if(index < sectionsLength) {
                    current = $(settings.sectionContainer + "[data-index='" + index + "']");
                    next = $(settings.sectionContainer + "[data-index='" + (index + 1) + "']");

                    if(next) {
                        current.removeClass("active");
                        next.addClass("active");

                        $(".navigation li a" + "[data-index='" + index + "']").removeClass("active");
                        $(".navigation li a" + "[data-index='" + (index + 1) + "']").addClass("active");
                    }

                    pos = (index * 100) * -1;
                    el.scrollPage(settings, pos);
                }
            };

            /**
             * @description changes the classes on the list items while scrolling up
             */
            $.fn.moveUp = function() {
                var el = $(this);
                index = $(settings.sectionContainer +".active").data("index");

                if(index <= sectionsLength && index > 1) {
                    current = $(settings.sectionContainer + "[data-index='" + index + "']");
                    next = $(settings.sectionContainer + "[data-index='" + (index - 1) + "']");

                    if(next) {
                        current.removeClass("active");
                        next.addClass("active");

                        $(".navigation li a" + "[data-index='" + index + "']").removeClass("active");
                        $(".navigation li a" + "[data-index='" + (index - 1) + "']").addClass("active");
                    }

                    pos = ((next.data("index") - 1) * 100) * -1;
                    el.scrollPage(settings, pos);
                }
            };

            function init_scroll(event, delta) {
                deltaOfInterest = delta;
                var timeNow = new Date().getTime();

                // Cancel scroll if currently animating or within quiet period
                if(timeNow - lastAnimation < quietPeriod + settings.animationTime) {
                    event.preventDefault();
                    return;
                }

                if (deltaOfInterest < 0) {
                    el.moveDown()
                } else {
                    el.moveUp()
                }
                lastAnimation = timeNow;
            }

            /**
             * @description Positioning all sections among themselves
             */
            $.each( sections, function(i) {
                $(this).css({
                    position: "absolute",
                    top: topPos + "%"
                }).addClass("section").attr("data-index", i+1);
                topPos = topPos + 100;

            });

            if(window.location.hash != "" && window.location.hash != "#1") {
                init_index =  window.location.hash.replace("#", "");
                $(settings.sectionContainer + "[data-index='" + init_index + "']").addClass("active");
                $(".navigation li a" + "[data-index='" + init_index + "']").addClass("active");

                next = $(settings.sectionContainer + "[data-index='" + (init_index) + "']");
                if(next) {
                    next.addClass("active");
                    $(".navigation li a" + "[data-index='" + (init_index) + "']").addClass("active");

                    if (history.replaceState) {
                        var href = window.location.href.substr(0,window.location.href.indexOf('#')) + "#" + (init_index);
                        history.pushState( {}, document.title, href );
                    }
                }
                pos = ((init_index - 1) * 100) * -1;
                el.scrollPage(settings, pos);

            }else{
                $(settings.sectionContainer + "[data-index='1']").addClass("active")
                $(".navigation li a" + "[data-index='1']").addClass("active");
            }

            /**
             * @description Event listener on click event. Changes the classes according to the current list item index
             */
            $(".navigation li a").click(function (){
                var page_index = $(this).data("index");

                if (!$(this).hasClass("active")) {
                    current = $(settings.sectionContainer + ".active");
                    next = $(settings.sectionContainer + "[data-index='" + (page_index) + "']");

                    if(next) {
                        current.removeClass("active");
                        next.addClass("active");

                        $(".navigation li a" + ".active").removeClass("active");
                        $(".navigation li a" + "[data-index='" + (page_index) + "']").addClass("active");
                    }

                    pos = ((page_index - 1) * 100) * -1;
                    el.scrollPage(settings, pos);
                }
            });

            /**
             * @description binding on scrolling with the mouse wheel
             */
            $(document).bind('mousewheel DOMMouseScroll', function(event) {
                event.preventDefault();
                var delta = event.originalEvent.wheelDelta || -event.originalEvent.detail;
                init_scroll(event, delta);
            });
        });
    }

}(window.jQuery);


